# LeadFinder
Estrutura: `public/index.html` (interface) + `api/search.js` (busca real, Vercel Function).
Deploy: suba no GitHub, importe na Vercel (sem build; Framework: Other). Chave do Google é opcional (Settings > Environment Variables > GOOGLE_PLACES_API_KEY; ative "Places API (New)").
Teste local: `npx vercel dev`.
