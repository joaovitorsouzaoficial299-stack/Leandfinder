// Vercel Function: GET /api/search?category=&location=&radius=&custom=
// Fonte: Google Places (se GOOGLE_PLACES_API_KEY existir) ou OpenStreetMap (Nominatim + Overpass), sem chave.
const OSM = {
  loja: '["shop"]', rest: '["amenity"~"^(restaurant|fast_food|bar|cafe)$"]', barb: '["shop"~"^(hairdresser|barber)$"]',
  salao: '["shop"~"^(hairdresser|beauty)$"]', odon: '["amenity"="dentist"]', acad: '["leisure"="fitness_centre"]',
  assist: '["shop"~"^(mobile_phone|computer|electronics)$"]', imob: '["office"="estate_agent"]', ofic: '["shop"="car_repair"]',
  pet: '["shop"="pet"]', roupa: '["shop"="clothes"]', cel: '["shop"="mobile_phone"]', local: '["shop"]', perto: '["shop"]'
};
const GQ = { loja: 'lojas', rest: 'restaurantes', barb: 'barbearias', salao: 'salões de beleza', odon: 'clínicas odontológicas', acad: 'academias',
  assist: 'assistências técnicas', imob: 'imobiliárias', ofic: 'oficinas mecânicas', pet: 'pet shops', roupa: 'lojas de roupas', cel: 'lojas de celulares',
  local: 'empresas', perto: 'comércios' };
const SOCIAL = /(instagram\.com|facebook\.com|fb\.com|linktr\.ee|wa\.me|whatsapp\.com)/i;
const UA = { 'User-Agent': 'LeadFinder/1.0 (prospeccao de leads)' };

function waFrom(phone) {
  const d = String(phone || '').replace(/\D/g, '').replace(/^55/, '');
  return d.length === 11 && d[2] === '9' ? '55' + d : '';
}
function split(url, ig, phone, wa) {
  let site = url || '', insta = ig || '';
  if (site && SOCIAL.test(site)) { if (/instagram/i.test(site) && !insta) insta = site; site = ''; }
  if (insta.startsWith('http')) insta = '@' + insta.replace(/\/$/, '').split('/').pop();
  return { website: site, instagram: insta, whatsapp: String(wa || '').replace(/\D/g, '') || waFrom(phone) };
}
async function geocode(q) {
  const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=' + encodeURIComponent(q), { headers: UA });
  const j = await r.json();
  if (!j[0]) throw new Error('Localização não encontrada');
  return { lat: +j[0].lat, lng: +j[0].lon };
}
async function google(p, c, key) {
  const label = p.category === 'custom' ? (p.custom || 'empresas') : GQ[p.category] || 'empresas';
  const r = await fetch('https://places.googleapis.com/v1/places:searchText', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': key,
      'X-Goog-FieldMask': 'places.id,places.displayName,places.formattedAddress,places.rating,places.userRatingCount,places.websiteUri,places.nationalPhoneNumber,places.location,places.currentOpeningHours.openNow,places.primaryTypeDisplayName' },
    body: JSON.stringify({ textQuery: `${label} em ${p.location}`, languageCode: 'pt-BR', pageSize: 20,
      locationBias: { circle: { center: { latitude: c.lat, longitude: c.lng }, radius: Math.min(50000, p.radius * 1000) } } })
  });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error?.message || 'Erro Google Places');
  return (j.places || []).map(x => ({
    id: 'gp-' + x.id, name: x.displayName?.text || 'Sem nome', category: x.primaryTypeDisplayName?.text || label,
    address: x.formattedAddress || '', rating: x.rating ?? null, reviews: x.userRatingCount ?? null,
    phone: x.nationalPhoneNumber || '', hours: '', openNow: x.currentOpeningHours?.openNow ?? null,
    lat: x.location?.latitude, lng: x.location?.longitude, ...split(x.websiteUri, '', x.nationalPhoneNumber)
  }));
}
async function osm(p, c) {
  const f = p.category === 'custom' ? `["name"~"${String(p.custom || '').replace(/["\\]/g, '')}",i]` : OSM[p.category] || '["shop"]';
  const q = `[out:json][timeout:25];nwr${f}["name"](around:${p.radius * 1000},${c.lat},${c.lng});out center tags 120;`;
  const r = await fetch('https://overpass-api.de/api/interpreter', { method: 'POST', headers: { ...UA, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'data=' + encodeURIComponent(q) });
  if (!r.ok) throw new Error('Overpass indisponível');
  const j = await r.json();
  return (j.elements || []).map(e => {
    const t = e.tags || {}, phone = t.phone || t['contact:phone'] || t['contact:mobile'] || '';
    const addr = [t['addr:street'], t['addr:housenumber'], t['addr:suburb']].filter(Boolean).join(', ');
    return { id: `osm-${e.type}-${e.id}`, name: t.name, category: t.shop || t.amenity || t.office || t.leisure || 'Negócio', address: addr || 'Endereço não informado',
      rating: null, reviews: null, phone, hours: t.opening_hours || '', openNow: null, lat: e.lat ?? e.center?.lat, lng: e.lon ?? e.center?.lon,
      ...split(t.website || t['contact:website'], t['contact:instagram'] || t.instagram, phone, t['contact:whatsapp']) };
  });
}
module.exports = async (req, res) => {
  try {
    const p = { category: req.query.category || 'local', location: (req.query.location || '').trim(), radius: Math.min(50, +req.query.radius || 10), custom: req.query.custom || '' };
    if (!p.location) return res.status(400).json({ error: 'Informe a localização' });
    const c = await geocode(p.location);
    const key = process.env.GOOGLE_PLACES_API_KEY;
    const leads = key ? await google(p, c, key) : await osm(p, c);
    const [city, state] = p.location.split(',').map(s => s.trim());
    res.setHeader('Cache-Control', 's-maxage=3600');
    res.json({ source: key ? 'Google Places' : 'OpenStreetMap', leads: leads.map(l => ({ ...l, city: city || '', state: state || '' })) });
  } catch (e) { res.status(502).json({ error: e.message }); }
};
